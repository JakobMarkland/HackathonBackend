package com.example.demo.model;

public class VoteType {

}
